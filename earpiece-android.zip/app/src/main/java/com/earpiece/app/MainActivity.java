package com.earpiece.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** The main screen: the lamp that starts and stops listening, the line to say, and what was heard. */
public final class MainActivity extends Activity implements Hub.Listener {
    static final int WINGS = 0xFF0C1222, FLAT = 0xFF141C33, EDGE = 0xFF263252, BLUE = 0xFF8FB0FF,
            SCRIPT = 0xFFE9EDF8, DIM = 0xFF8A96B5, FAINT = 0xFF5F6B8C, AMBER = 0xFFF2B34C,
            GO = 0xFF58D691, STOP = 0xFFF0605D, GLASS = 0xFF2C3A66, BEZEL = 0xFF070B15;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int ASK_PERMISSIONS = 7;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private View lamp;
    private GradientDrawable lens;
    private TextView status, sub, notice, line, lineHeard, empty, clear;
    private LinearLayout lineBox, log;
    private EditText ask;
    private boolean levelDriven;

    private final Runnable meter = new Runnable() {
        @Override public void run() {
            if (levelDriven) {
                double db = 20 * Math.log10(Hub.level + 1e-7);
                float x = (float) Math.max(0.06, Math.min(1, (db + 62) / 42));
                lamp.setAlpha(0.45f + 0.55f * x);
            }
            ui.postDelayed(this, 100);
        }
    };

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView link(String s) {
        TextView t = text(s, 16, BLUE, true);
        t.setPadding(0, dp(10), 0, dp(10));
        t.setClickable(true);
        return t;
    }

    private LinearLayout.LayoutParams below(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(MATCH, WRAP);
        p.topMargin = dp(topDp);
        return p;
    }

    private GradientDrawable panel(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(10));
        return g;
    }

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Speaker.init(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(14), dp(20), dp(18));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(WINGS);
        scroll.addView(root, new ViewGroup.LayoutParams(MATCH, WRAP));
        setContentView(scroll);

        // name and Settings
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = text("Earpiece", 20, SCRIPT, true);
        mark.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        top.addView(mark, new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView settings = link("Settings");
        settings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, SettingsActivity.class)); }
        });
        top.addView(settings, new LinearLayout.LayoutParams(WRAP, WRAP));
        root.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));

        // a message when something needs attention; tap to dismiss
        notice = text("", 15, SCRIPT, false);
        notice.setBackground(panel(FLAT));
        notice.setPadding(dp(14), dp(12), dp(14), dp(12));
        notice.setVisibility(View.GONE);
        notice.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { Hub.notice(""); }
        });
        root.addView(notice, below(12));

        // the lamp
        lens = new GradientDrawable();
        lens.setShape(GradientDrawable.OVAL);
        lens.setColor(GLASS);
        lens.setStroke(dp(13), BEZEL);
        lamp = new View(this);
        lamp.setBackground(lens);
        lamp.setContentDescription("Start listening");
        lamp.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (Hub.running) stopListening(); else startListening(); }
        });
        LinearLayout.LayoutParams lampAt = new LinearLayout.LayoutParams(dp(190), dp(190));
        lampAt.gravity = Gravity.CENTER_HORIZONTAL;
        lampAt.topMargin = dp(26);
        root.addView(lamp, lampAt);

        status = text("Off", 22, SCRIPT, true);
        status.setGravity(Gravity.CENTER);
        root.addView(status, below(20));
        sub = text("", 15, DIM, false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, below(4));

        // the line to say
        lineBox = new LinearLayout(this);
        lineBox.setOrientation(LinearLayout.VERTICAL);
        lineBox.setVisibility(View.GONE);
        lineBox.addView(text("Your line", 15, DIM, false));
        line = text("", 34, SCRIPT, true);
        line.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        lineBox.addView(line, below(4));
        lineHeard = text("", 15, DIM, false);
        lineBox.addView(lineHeard, below(6));
        TextView again = link("Say it again");
        again.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { String s = line.getText().toString(); if (!s.isEmpty()) speak(s); }
        });
        lineBox.addView(again, new LinearLayout.LayoutParams(WRAP, WRAP));
        root.addView(lineBox, below(24));

        // what was heard
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text("Heard so far", 15, DIM, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        clear = link("Clear");
        clear.setPadding(0, dp(4), 0, dp(4));
        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { Hub.clear(); }
        });
        head.addView(clear, new LinearLayout.LayoutParams(WRAP, WRAP));
        root.addView(head, below(24));
        root.addView(rule(), new LinearLayout.LayoutParams(MATCH, dp(1)));
        empty = text("Nothing yet. Before you rely on it:\n\n1. Add your API key in Settings.\n2. Connect your earbud, then tap Test the voice. You should hear it in your ear and nowhere else.\n3. Tap the lamp, lock the phone, and ask the room a question.", 15, DIM, false);
        root.addView(empty, below(12));
        log = new LinearLayout(this);
        log.setOrientation(LinearLayout.VERTICAL);
        root.addView(log, new LinearLayout.LayoutParams(MATCH, WRAP));

        // pushes the tools to the bottom on a tall screen
        root.addView(new View(this), new LinearLayout.LayoutParams(MATCH, dp(24), 1f));

        // try it by typing, test the voice
        root.addView(text("Type a question to try it without the microphone", 14, DIM, false), new LinearLayout.LayoutParams(MATCH, WRAP));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        ask = new EditText(this);
        ask.setHint("What's the capital of California?");
        ask.setHintTextColor(FAINT);
        ask.setTextColor(SCRIPT);
        ask.setTextSize(16);
        ask.setSingleLine(true);
        ask.setImeOptions(EditorInfo.IME_ACTION_SEND);
        ask.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND) { submit(); return true; }
                return false;
            }
        });
        row.addView(ask, new LinearLayout.LayoutParams(0, WRAP, 1f));
        Button send = button("Ask");
        send.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { submit(); }
        });
        row.addView(send, new LinearLayout.LayoutParams(WRAP, WRAP));
        root.addView(row, below(4));
        Button test = button("Test the voice");
        test.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { speak("Sacramento"); }
        });
        root.addView(test, below(8));
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(16);
        return b;
    }

    private View rule() {
        View v = new View(this);
        v.setBackgroundColor(EDGE);
        return v;
    }

    @Override protected void onResume() {
        super.onResume();
        Hub.setListener(this);
        refresh();
        ui.removeCallbacks(meter);
        ui.post(meter);
    }

    @Override protected void onPause() {
        ui.removeCallbacks(meter);
        Hub.setListener(null);
        super.onPause();
    }

    @Override public void onHubChanged() { refresh(); }

    private void speak(String s) {
        if (!Speaker.say(this, s, Prefs.load(this)))
            Hub.notice("Nothing was spoken, because no earbud or headphones are connected. Connect one, or turn off \"Never use the phone speaker\" in Settings.");
    }

    private void submit() {
        String q = ask.getText().toString().trim();
        if (q.isEmpty()) return;
        if (Prefs.load(this).apiKey.trim().isEmpty()) { startActivity(new Intent(this, SettingsActivity.class)); return; }
        ask.setText("");
        Hub.notice("");
        Brain.typed(this, q);
    }

    private void startListening() {
        if (Prefs.load(this).apiKey.trim().isEmpty()) { startActivity(new Intent(this, SettingsActivity.class)); return; }
        ArrayList<String> need = new ArrayList<String>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            need.add("android.permission.POST_NOTIFICATIONS");
        if (!need.isEmpty()) { requestPermissions(need.toArray(new String[0]), ASK_PERMISSIONS); return; }
        launch();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != ASK_PERMISSIONS) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launch();
        else Hub.notice("The microphone permission is off, so the app cannot listen. Turn it on under the phone's Settings, Apps, Earpiece, Permissions.");
    }

    private void launch() {
        Hub.notice("");
        try {
            startForegroundService(new Intent(this, ListenService.class).setAction(ListenService.ACTION_START));
        } catch (RuntimeException e) {
            Hub.notice("Android would not let listening start: " + e.getMessage());
        }
    }

    private void stopListening() {
        stopService(new Intent(this, ListenService.class));
    }

    private static String seconds(long ms) { return String.format(Locale.US, "%.1f s", ms / 1000.0); }

    private void refresh() {
        boolean running = Hub.running;
        int color = GLASS;
        String st = "Off";
        String su = Prefs.load(this).apiKey.trim().isEmpty() ? "Add your API key in Settings to begin" : "Tap the lamp to start listening";
        boolean byLevel = false;
        float alpha = 0.6f;
        if (running) { color = AMBER; st = "Listening"; su = "You can lock the phone. It keeps listening."; byLevel = true; }
        if (running && Hub.hearing) { st = "Hearing speech"; su = "An answer follows the next pause"; }
        if (Hub.transcribing.get() > 0) { color = BLUE; st = "Writing it down"; su = ""; byLevel = false; alpha = 1f; }
        if (Hub.thinking.get() > 0) { color = BLUE; st = "Finding the answer"; su = ""; byLevel = false; alpha = 1f; }
        if (Hub.speaking) { color = GO; st = "Saying it"; su = ""; byLevel = false; alpha = 1f; }
        lens.setColor(color);
        levelDriven = byLevel;
        if (!byLevel) lamp.setAlpha(alpha);
        lamp.setContentDescription(running ? "Stop listening" : "Start listening");
        status.setText(st);
        sub.setText(su);

        String n = Hub.notice;
        notice.setText(n + (n.isEmpty() ? "" : "\n\nTap to dismiss."));
        notice.setVisibility(n.isEmpty() ? View.GONE : View.VISIBLE);

        List<Entry> all = Hub.snapshot();
        log.removeAllViews();
        Entry last = null;
        int shown = 0;
        for (int i = all.size() - 1; i >= 0 && shown < 40; i--) {
            Entry e = all.get(i);
            if (last == null && (e.status == Entry.ANSWERED || e.status == Entry.UNSPOKEN)) last = e;
            log.addView(row(e), new LinearLayout.LayoutParams(MATCH, WRAP));
            log.addView(rule(), new LinearLayout.LayoutParams(MATCH, dp(1)));
            shown++;
        }
        empty.setVisibility(shown == 0 ? View.VISIBLE : View.GONE);
        clear.setVisibility(shown == 0 ? View.INVISIBLE : View.VISIBLE);
        lineBox.setVisibility(last == null ? View.GONE : View.VISIBLE);
        if (last != null) {
            line.setText(last.answer);
            lineHeard.setText("to “" + last.heard + "”");
        }
    }

    private View row(final Entry e) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(12), 0, dp(12));
        String heard = e.heard;
        box.addView(text(heard.isEmpty() ? "Writing down what was said…" : "“" + heard + "”", 15, DIM, false));
        int s = e.status;
        if (s == Entry.THINKING) {
            box.addView(text("Finding the answer…", 14, FAINT, false), below(3));
        } else if (s == Entry.ANSWERED || s == Entry.LATE || s == Entry.UNSPOKEN) {
            TextView a = text(e.answer, 19, SCRIPT, true);
            a.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            a.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { speak(e.answer); }
            });
            box.addView(a, below(3));
            StringBuilder t = new StringBuilder();
            if (e.sttMs >= 0) t.append("text ").append(seconds(e.sttMs));
            if (e.llmMs >= 0) { if (t.length() > 0) t.append(", "); t.append("answer ").append(seconds(e.llmMs)); }
            if (s == Entry.LATE) t.append(t.length() > 0 ? ". " : "").append("Too late to say.");
            if (s == Entry.UNSPOKEN) t.append(t.length() > 0 ? ". " : "").append("Not spoken: no earbud connected.");
            if (t.length() > 0) box.addView(text(t.toString(), 13, s == Entry.UNSPOKEN ? AMBER : DIM, false), below(2));
        } else if (s == Entry.SKIPPED) {
            box.addView(text("No answer needed", 14, FAINT, false), below(3));
        } else if (s == Entry.ERROR) {
            box.addView(text(e.error, 14, STOP, false), below(3));
        }
        return box;
    }
}
