package com.earpiece.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Talks to the answer service (any service with OpenAI-style endpoints). */
final class Api {
    private Api() {}

    static final int NETWORK = -1, TIMEOUT = -2;

    static final class Failure extends Exception {
        final int kind;             // an HTTP status, or NETWORK / TIMEOUT
        final double retryAfter;

        Failure(int kind, String message, double retryAfter) {
            super(message == null ? "" : message);
            this.kind = kind;
            this.retryAfter = retryAfter;
        }
    }

    private static String say(Failure f) { String m = f.getMessage(); return m == null ? "" : m; }

    static String explain(Failure f, String what) {
        int k = f.kind;
        String m = say(f);
        if (k == NETWORK) return "Can't reach the answer service. Check this phone's internet connection.";
        if (k == TIMEOUT) return "The answer service took too long to reply. The connection may be weak here.";
        if (k == 401 || k == 403) return "The API key was refused. Check it in Settings.";
        if (k == 404 || (k == 400 && m.toLowerCase().contains("model")))
            return "The service does not offer the model set for " + what + ". Change it in Settings. (" + (m.length() > 140 ? m.substring(0, 140) : m) + ")";
        if (k == 429) return "The service says you are sending too much for your plan. Waiting " + (int) Math.ceil(f.retryAfter > 0 ? f.retryAfter : 20) + " seconds before trying again.";
        return "The answer service returned an error (" + k + "). " + (m.length() > 160 ? m.substring(0, 160) : m);
    }

    private static HttpURLConnection open(Prefs p, String path, String method, int readTimeoutMs) throws IOException {
        String base = p.baseUrl.trim().replaceAll("/+$", "");
        HttpURLConnection c = (HttpURLConnection) new URL(base + path).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(8000);
        c.setReadTimeout(readTimeoutMs);
        c.setRequestProperty("Authorization", "Bearer " + p.apiKey.trim());
        c.setRequestProperty("Accept", "application/json");
        return c;
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    /** Sends the request body (if any), returns the response text, or throws a Failure that says what went wrong. */
    private static String send(Prefs p, String path, String method, String contentType, byte[] body, int readTimeoutMs) throws Failure {
        HttpURLConnection c = null;
        try {
            c = open(p, path, method, readTimeoutMs);
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", contentType);
                c.setFixedLengthStreamingMode(body.length);
                OutputStream os = c.getOutputStream();
                os.write(body);
                os.close();
            }
            int code = c.getResponseCode();
            boolean ok = code >= 200 && code < 300;
            InputStream in = ok ? c.getInputStream() : c.getErrorStream();
            String text = in == null ? "" : readAll(in);
            if (ok) return text;
            String msg = text;
            try {
                Object e = new JSONObject(text).opt("error");
                if (e instanceof JSONObject) msg = ((JSONObject) e).optString("message", text);
                else if (e != null) msg = String.valueOf(e);
            } catch (JSONException ignored) { }
            double retry = 0;
            String ra = c.getHeaderField("retry-after");
            if (ra != null) { try { retry = Double.parseDouble(ra.trim()); } catch (NumberFormatException ignored) { } }
            throw new Failure(code, msg, retry);
        } catch (SocketTimeoutException e) {
            throw new Failure(TIMEOUT, e.getMessage(), 0);
        } catch (IOException e) {
            throw new Failure(NETWORK, e.getMessage(), 0);
        } catch (RuntimeException e) {
            throw new Failure(NETWORK, String.valueOf(e), 0);     // e.g. an address that isn't a web address
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static void field(ByteArrayOutputStream o, String boundary, String name, String value) throws IOException {
        o.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + value + "\r\n").getBytes(StandardCharsets.UTF_8));
    }

    static String transcribe(Prefs p, byte[] wav) throws Failure {
        String boundary = "----earpiece" + Long.toHexString(System.nanoTime());
        ByteArrayOutputStream o = new ByteArrayOutputStream(wav.length + 1024);
        try {
            field(o, boundary, "model", p.sttModel.trim());
            field(o, boundary, "response_format", "json");
            field(o, boundary, "temperature", "0");
            String lang = p.language == null ? "" : p.language.trim().toLowerCase();
            if (!lang.isEmpty()) field(o, boundary, "language", lang);
            o.write(("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"speech.wav\"\r\nContent-Type: audio/wav\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            o.write(wav);
            o.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new Failure(NETWORK, e.getMessage(), 0);
        }
        String text = send(p, "/audio/transcriptions", "POST", "multipart/form-data; boundary=" + boundary, o.toByteArray(), 20000);
        try {
            return new JSONObject(text).optString("text", "");
        } catch (JSONException e) {
            throw new Failure(NETWORK, "The service sent a reply that could not be read.", 0);
        }
    }

    private static JSONObject chatBody(String model, String system, String user, boolean oldLimitName, boolean noReasoningField) throws JSONException {
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("temperature", 0.2);
        JSONArray messages = new JSONArray();
        messages.put(new JSONObject().put("role", "system").put("content", system));
        messages.put(new JSONObject().put("role", "user").put("content", user));
        body.put("messages", messages);
        String m = model.toLowerCase();
        int limit = 80;
        // thinking models: turn the thinking off where the service allows it, otherwise keep it as short as it goes
        if (noReasoningField) limit = 400;
        else if (m.contains("qwen")) body.put("reasoning_effort", "none");
        else if (m.contains("gpt-oss")) { body.put("reasoning_effort", "low"); limit = 400; }
        body.put(oldLimitName ? "max_tokens" : "max_completion_tokens", limit);
        return body;
    }

    static String ask(Prefs p, String system, String user) throws Failure {
        String model = p.chatModel.trim();
        String text;
        try {
            byte[] first = chatBody(model, system, user, false, false).toString().getBytes(StandardCharsets.UTF_8);
            try {
                text = send(p, "/chat/completions", "POST", "application/json", first, 15000);
            } catch (Failure f) {
                String m = say(f).toLowerCase();
                // some services only know the older name for the length limit, or reject the thinking setting
                if (f.kind == 400 && m.contains("max_completion_tokens"))
                    text = send(p, "/chat/completions", "POST", "application/json", chatBody(model, system, user, true, false).toString().getBytes(StandardCharsets.UTF_8), 15000);
                else if (f.kind == 400 && m.contains("reasoning"))
                    text = send(p, "/chat/completions", "POST", "application/json", chatBody(model, system, user, false, true).toString().getBytes(StandardCharsets.UTF_8), 15000);
                else throw f;
            }
            JSONArray choices = new JSONObject(text).optJSONArray("choices");
            if (choices == null || choices.length() == 0) return "";
            JSONObject first0 = choices.optJSONObject(0);
            JSONObject message = first0 == null ? null : first0.optJSONObject("message");
            if (message == null || message.isNull("content")) return "";
            return message.optString("content", "");
        } catch (JSONException e) {
            throw new Failure(NETWORK, "The service sent a reply that could not be read.", 0);
        }
    }

    /** Checks the key and that both models are offered. Returns a sentence for the Settings screen. */
    static String check(Prefs p) throws Failure {
        String text = send(p, "/models", "GET", null, null, 12000);
        StringBuilder missing = new StringBuilder();
        try {
            JSONArray data = new JSONObject(text).optJSONArray("data");
            if (data != null && data.length() > 0) {
                String[] want = {p.sttModel.trim(), p.chatModel.trim()};
                for (String w : want) {
                    boolean found = false;
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject m = data.optJSONObject(i);
                        if (m != null && w.equals(m.optString("id", ""))) { found = true; break; }
                    }
                    if (!found) { if (missing.length() > 0) missing.append(", "); missing.append(w); }
                }
            }
        } catch (JSONException ignored) { }
        return missing.length() > 0 ? "The key works, but this service does not list: " + missing : "The key works.";
    }
}
