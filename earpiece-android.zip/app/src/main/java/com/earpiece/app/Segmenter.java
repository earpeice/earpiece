package com.earpiece.app;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Cuts the microphone stream into utterances: starts when sound rises clearly above the
 * background, ends after a pause. Same rules as the web version.
 */
final class Segmenter {
    interface Sink {
        void onSegment(short[] samples, int ms, int voicedMs, boolean cut);
        void onSpeech(boolean on);
    }

    // Sensitivity 1..10 -> how many times louder than the background counts as speech.
    private static final double[] K_ON = {6, 5.2, 4.5, 3.9, 3.4, 3.0, 2.6, 2.3, 2.0, 1.8};
    private static final int PRE_FRAMES = 20;    // 400 ms kept so the first syllable isn't lost
    private static final int MAX_FRAMES = 700;   // cut after 14 s without a pause

    final int rate;
    private final int frameLen;
    private final Sink sink;
    private final short[] frame;
    private int fill;

    private final ArrayDeque<short[]> pre = new ArrayDeque<short[]>();
    private ArrayList<short[]> seg;
    private final double[] segRms = new double[MAX_FRAMES + 1];
    private int segRmsN;

    private double nf;          // background level
    private long frames;
    private int run, quiet, voiced;
    private double kOn, kOff, floorMin;
    private int hang;
    private boolean muted, inSpeech;
    volatile double level;

    Segmenter(int rate, int sensitivity, int pauseMs, Sink sink) {
        this.rate = rate;
        this.frameLen = Math.round(rate * 0.02f);
        this.frame = new short[frameLen];
        this.sink = sink;
        configure(sensitivity, pauseMs);
    }

    void configure(int sensitivity, int pauseMs) {
        int s = Math.min(10, Math.max(1, sensitivity));
        kOn = K_ON[s - 1];
        kOff = Math.max(1.3, kOn * 0.6);
        floorMin = 0.0015 * (kOn / 3);
        hang = Math.max(10, Math.round(pauseMs / 20f));
    }

    double background() { return nf; }

    void setMuted(boolean on) {
        if (on == muted) return;
        muted = on;
        if (on) drop();
    }

    private void drop() {
        seg = null; segRmsN = 0; run = 0; quiet = 0; voiced = 0; pre.clear();
        if (inSpeech) { inSpeech = false; sink.onSpeech(false); }
    }

    void push(short[] buf, int n) {
        for (int i = 0; i < n; i++) {
            frame[fill++] = buf[i];
            if (fill == frameLen) { fill = 0; frame(Arrays.copyOf(frame, frameLen)); }
        }
    }

    private void frame(short[] f) {
        double sum = 0;
        for (int i = 0; i < f.length; i++) { double x = f[i] / 32768.0; sum += x * x; }
        double r = Math.sqrt(sum / f.length);
        level = r;
        if (muted) return;
        frames++;
        if (frames == 1) nf = Math.max(1e-5, r);
        double thrOn = Math.max(nf * kOn, floorMin);
        double thrOff = Math.max(nf * kOff, floorMin * 0.7);

        if (seg == null) {
            // background level follows quiet quickly, and anything short of speech slowly
            if (r < nf) nf = Math.max(1e-5, nf * 0.7 + r * 0.3);
            else if (r < thrOn) nf += (r - nf) * 0.02;
            pre.addLast(f);
            if (pre.size() > PRE_FRAMES) pre.pollFirst();
            run = r > thrOn ? run + 1 : Math.max(0, run - 1);
            if (run >= 4) {
                seg = new ArrayList<short[]>(pre);
                pre.clear();
                segRmsN = 0; voiced = run; quiet = 0;
                inSpeech = true;
                sink.onSpeech(true);
            }
            return;
        }
        seg.add(f);
        if (segRmsN < segRms.length) segRms[segRmsN++] = r;
        if (r > thrOn) voiced++;
        quiet = r > thrOff ? 0 : quiet + 1;
        boolean tooLong = seg.size() >= MAX_FRAMES;
        if (quiet >= hang || tooLong) finish(tooLong && quiet < hang);
    }

    private void finish(boolean cut) {
        ArrayList<short[]> fr = seg;
        int used = fr.size() - Math.max(0, quiet - 10);     // keep 200 ms of trailing quiet
        short[] out = new short[used * frameLen];
        for (int i = 0; i < used; i++) System.arraycopy(fr.get(i), 0, out, i * frameLen, frameLen);
        // learn the background from the quietest tenth of what was just captured;
        // this is what stops steady noise (music, a fan) from triggering forever
        double p10 = nf;
        if (segRmsN > 0) {
            double[] sorted = Arrays.copyOf(segRms, segRmsN);
            Arrays.sort(sorted);
            p10 = sorted[(int) Math.floor(segRmsN * 0.1)];
        }
        nf = Math.max(1e-5, nf * 0.5 + p10 * 0.5);
        int ms = used * 20, voicedMs = voiced * 20;
        seg = null; segRmsN = 0; run = 0; quiet = 0; voiced = 0; pre.clear();
        inSpeech = false;
        sink.onSpeech(false);
        if (voicedMs >= 240 && ms >= 400) sink.onSegment(out, ms, voicedMs, cut);
    }
}
