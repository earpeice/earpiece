package com.earpiece.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;

/**
 * Listens in the background, screen on or off. Android keeps it alive because it shows
 * an ongoing notification and holds the microphone as a foreground service.
 */
public final class ListenService extends Service {
    static final String ACTION_START = "com.earpiece.app.START";
    static final String ACTION_STOP = "com.earpiece.app.STOP";
    static final String ACTION_RELOAD = "com.earpiece.app.RELOAD";

    private static final String CHANNEL = "listening";
    private static final int RATE = 16000;

    private PowerManager.WakeLock wake;
    private Thread audio, hum;
    private volatile boolean capturing;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();

        if (ACTION_RELOAD.equals(action)) {          // the microphone choice changed in Settings
            if (capturing) { stopAudio(); startAudio(); } else stopSelf();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            Notification n = notification();
            if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(1, n);
        } catch (RuntimeException e) {
            Hub.notice("Android would not let listening start: " + e.getMessage());
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!capturing) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null && wake == null) {
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "earpiece:listening");
                wake.setReferenceCounted(false);
                wake.acquire();
            }
            Speaker.init(this);
            startAudio();
            Hub.running = true;
            Prefs p = Prefs.load(this);
            if (!Speaker.say(this, "Ready", p))
                Hub.notice("Listening, but no earbud or headphones are connected, so answers will not be spoken. Connect one, or turn off \"Never use the phone speaker\" in Settings.");
            Hub.changed();
        }
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        stopAudio();
        if (wake != null) { try { wake.release(); } catch (RuntimeException ignored) { } wake = null; }
        Hub.running = false;
        Hub.hearing = false;
        Hub.level = 0;
        Speaker.hush();
        stopForeground(Service.STOP_FOREGROUND_REMOVE);
        Hub.changed();
        super.onDestroy();
    }

    private Notification notification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Listening", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
        if (nm != null) nm.createNotificationChannel(ch);

        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), flags);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, ListenService.class).setAction(ACTION_STOP), flags);

        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Earpiece is listening")
                .setContentText("Tap to open. Stop ends it.")
                .setOngoing(true)
                .setContentIntent(open)
                .setVisibility(Notification.VISIBILITY_SECRET)
                .addAction(new Notification.Action.Builder(R.drawable.ic_stat, "Stop", stop).build());
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    private void startAudio() {
        capturing = true;
        audio = new Thread(new Runnable() {
            @Override public void run() { capture(); }
        }, "earpiece-audio");
        audio.start();
        if (Prefs.load(this).keepAwake) {
            hum = new Thread(new Runnable() {
                @Override public void run() { keepEarbudAwake(); }
            }, "earpiece-hum");
            hum.start();
        }
    }

    /**
     * Plays silence for as long as listening is on. A Bluetooth earbud that has gone idle takes a
     * moment to wake and swallows the start of whatever plays next, which for a one-word answer
     * can be most of it. Keeping the link open avoids that.
     */
    private void keepEarbudAwake() {
        AudioTrack track = null;
        try {
            int min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build())
                    .setBufferSizeInBytes(Math.max(min, 6400))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            track.play();
            short[] quiet = new short[1600];            // 100 ms
            for (int i = 0; i < quiet.length; i += 2) quiet[i] = 1;   // far below hearing, but not a dead-silent stream
            while (capturing) {
                if (track.write(quiet, 0, quiet.length) < 0) break;
            }
        } catch (Throwable ignored) {
            // answers still play without this; only the first syllable may be clipped
        } finally {
            if (track != null) {
                try { track.stop(); } catch (IllegalStateException ignored) { }
                track.release();
            }
        }
    }

    private void stopAudio() {
        capturing = false;
        Thread t = audio, h = hum;
        audio = null;
        hum = null;
        if (t != null && t != Thread.currentThread()) {
            try { t.join(1500); } catch (InterruptedException ignored) { }
        }
        if (h != null && h != Thread.currentThread()) {
            try { h.join(1000); } catch (InterruptedException ignored) { }
        }
    }

    private AudioDeviceInfo preferredMic(int choice) {
        if (choice == Prefs.MIC_AUTO) return null;
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return null;
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_INPUTS)) {
            int t = d.getType();
            if (choice == Prefs.MIC_PHONE && t == AudioDeviceInfo.TYPE_BUILTIN_MIC) return d;
            if (choice == Prefs.MIC_PLUGGED && (t == AudioDeviceInfo.TYPE_USB_DEVICE || t == AudioDeviceInfo.TYPE_USB_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADSET)) return d;
        }
        return null;
    }

    /** Runs on its own thread for as long as listening is on. */
    private void capture() {
        final Context app = getApplicationContext();
        AudioRecord rec = null;
        try {
            Prefs p = Prefs.load(app);
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) min = RATE;
            rec = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min * 2, RATE));
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("the microphone is not available");
            AudioDeviceInfo want = preferredMic(p.mic);
            if (want != null) rec.setPreferredDevice(want);
            rec.startRecording();
            if (rec.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("another app is using the microphone");

            Segmenter seg = new Segmenter(RATE, p.sensitivity, p.pauseMs, new Segmenter.Sink() {
                @Override public void onSegment(short[] samples, int ms, int voicedMs, boolean cut) { Brain.clip(app, samples, RATE); }
                @Override public void onSpeech(boolean on) { Hub.hearing = on; Hub.changed(); }
            });

            short[] buf = new short[320];               // 20 ms
            boolean mute = p.muteWhileSpeaking;
            long checked = SystemClock.elapsedRealtime();
            while (capturing) {
                int n = rec.read(buf, 0, buf.length);
                if (n < 0) throw new IllegalStateException("the microphone stopped (code " + n + ")");
                if (n == 0) continue;
                long t = SystemClock.elapsedRealtime();
                if (t - checked > 1500) {              // pick up changes made in Settings while running
                    checked = t;
                    p = Prefs.load(app);
                    seg.configure(p.sensitivity, p.pauseMs);
                    mute = p.muteWhileSpeaking;
                }
                seg.setMuted(mute && Hub.speaking);
                seg.push(buf, n);
                Hub.level = seg.level;
            }
        } catch (Throwable e) {
            if (capturing) {
                capturing = false;
                Hub.notice("Listening stopped: " + e.getMessage());
                stopSelf();
            }
        } finally {
            if (rec != null) {
                try { rec.stop(); } catch (IllegalStateException ignored) { }
                rec.release();
            }
            Hub.hearing = false;
            Hub.level = 0;
        }
    }
}
