package com.earpiece.app;

/** 16-bit mono WAV, turned up so quiet recordings are still clear to the transcriber. */
final class Wav {
    private Wav() {}

    static byte[] encode(short[] s, int rate) {
        int peak = 0;
        for (int i = 0; i < s.length; i++) { int a = Math.abs((int) s[i]); if (a > peak) peak = a; }
        double gain = peak > 0 ? Math.min(15.0, 0.85 * 32768.0 / peak) : 1.0;
        int data = s.length * 2;
        byte[] b = new byte[44 + data];
        ascii(b, 0, "RIFF"); le32(b, 4, 36 + data); ascii(b, 8, "WAVE");
        ascii(b, 12, "fmt "); le32(b, 16, 16); le16(b, 20, 1); le16(b, 22, 1);
        le32(b, 24, rate); le32(b, 28, rate * 2); le16(b, 32, 2); le16(b, 34, 16);
        ascii(b, 36, "data"); le32(b, 40, data);
        for (int i = 0; i < s.length; i++) {
            long v = Math.round(s[i] * gain);
            if (v > 32767) v = 32767; else if (v < -32768) v = -32768;
            le16(b, 44 + i * 2, (int) v);
        }
        return b;
    }

    private static void ascii(byte[] b, int o, String t) { for (int i = 0; i < t.length(); i++) b[o + i] = (byte) t.charAt(i); }
    private static void le16(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); }
    private static void le32(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }
}
