package com.earpiece.app;

import android.content.Context;
import android.os.SystemClock;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** Takes one utterance from sound to a spoken answer: transcribe, decide, ask, say. */
final class Brain {
    private Brain() {}

    private static final ExecutorService pool = Executors.newFixedThreadPool(3);
    private static final AtomicInteger inFlight = new AtomicInteger();
    private static final ArrayDeque<Long> recent = new ArrayDeque<Long>();
    private static volatile long pausedUntil;
    private static String lastSpoken = "";
    private static long lastSpokenAt;

    private static long now() { return SystemClock.elapsedRealtime(); }

    /** Called by the listening service with one clip of speech. */
    static void clip(Context c, final short[] samples, final int rate) {
        final Context app = c.getApplicationContext();
        long t = now();
        if (t < pausedUntil || inFlight.get() >= 3) return;
        synchronized (recent) {                     // the free plan allows 20 clips a minute
            while (!recent.isEmpty() && t - recent.peekFirst() > 60000) recent.pollFirst();
            if (recent.size() >= 18) return;
            recent.addLast(t);
        }
        final Entry e = new Entry();
        e.t0 = t;
        Hub.add(e);
        inFlight.incrementAndGet();
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    runClip(app, e, samples, rate);
                } catch (Throwable x) {
                    if (e.heard.isEmpty()) Hub.remove(e);
                    Hub.notice("Something went wrong: " + x);
                } finally {
                    inFlight.decrementAndGet();
                    Hub.changed();
                }
            }
        });
    }

    /** A question typed on the screen: always answered, and spoken. */
    static void typed(Context c, String question) {
        final Context app = c.getApplicationContext();
        final Entry e = new Entry();
        e.t0 = now();
        e.heard = question;
        e.status = Entry.THINKING;
        Hub.add(e);
        Hub.changed();
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    answer(app, Prefs.load(app), e, true);
                } catch (Throwable x) {
                    Hub.notice("Something went wrong: " + x);
                } finally {
                    Hub.changed();
                }
            }
        });
    }

    private static void runClip(Context app, Entry e, short[] samples, int rate) {
        Prefs p = Prefs.load(app);
        String text;
        Hub.transcribing.incrementAndGet();
        Hub.changed();
        try {
            long t = now();
            text = Api.transcribe(p, Wav.encode(samples, rate));
            e.sttMs = now() - t;
        } catch (Api.Failure f) {
            fail(e, f, "speech-to-text");
            return;
        } finally {
            Hub.transcribing.decrementAndGet();
        }
        String heard = TextRules.tidyHeard(text);
        if (TextRules.isJunk(heard)) { Hub.remove(e); return; }
        e.heard = heard;
        answer(app, p, e, false);
    }

    private static void answer(Context app, Prefs p, Entry e, boolean force) {
        if (!force && !p.answerAnything && !TextRules.looksLikeQuestion(e.heard)) { e.status = Entry.SKIPPED; return; }
        if (!force && e.heard.trim().split("\\s+").length < 2) { e.status = Entry.SKIPPED; return; }
        e.status = Entry.THINKING;
        Hub.thinking.incrementAndGet();
        Hub.changed();
        String raw;
        try {
            long t = now();
            raw = Api.ask(p, TextRules.systemPrompt(p), TextRules.userPrompt(e.heard, earlier(e)));
            e.llmMs = now() - t;
        } catch (Api.Failure f) {
            fail(e, f, "answers");
            return;
        } finally {
            Hub.thinking.decrementAndGet();
        }
        String text = TextRules.cleanAnswer(raw, p.maxWords);
        if (text.isEmpty()) { e.status = Entry.SKIPPED; return; }
        e.answer = text;
        e.latency = now() - e.t0;
        if (!force && e.latency > 12000) { e.status = Entry.LATE; return; }     // nobody wants an answer 12 s after the moment
        boolean repeat;
        synchronized (Brain.class) {
            long t = now();
            repeat = !force && text.equalsIgnoreCase(lastSpoken) && t - lastSpokenAt < 8000;
            if (!repeat) { lastSpoken = text; lastSpokenAt = t; }
        }
        e.status = Entry.ANSWERED;
        if (!repeat && (force || Hub.running)) {
            if (!Speaker.say(app, text, p)) e.status = Entry.UNSPOKEN;
        }
    }

    private static List<Entry> earlier(Entry e) {
        long t = now();
        ArrayList<Entry> out = new ArrayList<Entry>();
        for (Entry x : Hub.snapshot()) {
            if (x != e && !x.heard.isEmpty() && x.t0 <= e.t0 && t - x.t0 < 150000 && x.status != Entry.ERROR) out.add(x);
        }
        while (out.size() > 6) out.remove(0);
        return out;
    }

    private static void fail(Entry e, Api.Failure f, String what) {
        String msg = Api.explain(f, what);
        if (e.heard.isEmpty()) Hub.remove(e);
        else { e.status = Entry.ERROR; e.error = msg; }
        if (f.kind == 429) pausedUntil = now() + (long) Math.ceil(f.retryAfter > 0 ? f.retryAfter : 20) * 1000L;
        Hub.notice(msg);
    }
}
