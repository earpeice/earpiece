package com.earpiece.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/** The voice in the ear. Uses the phone's own text-to-speech, played as media so it goes to the earbud. */
final class Speaker {
    private Speaker() {}

    private static TextToSpeech tts;
    private static boolean ready;
    private static final ArrayList<String> waiting = new ArrayList<String>();
    private static float waitingRate = 1f;
    private static int counter;
    private static final AtomicInteger active = new AtomicInteger();
    private static final Handler main = new Handler(Looper.getMainLooper());

    static synchronized void init(Context c) {
        if (tts != null) return;
        final Context app = c.getApplicationContext();
        tts = new TextToSpeech(app, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) { started(status); }
        });
    }

    private static synchronized void started(int status) {
        if (status != TextToSpeech.SUCCESS) {
            tts = null;
            waiting.clear();
            Hub.notice("This phone has no working text-to-speech voice. Install or enable one under the phone's Settings, Accessibility, Text-to-speech output.");
            return;
        }
        tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build());
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { active.incrementAndGet(); Hub.speaking = true; Hub.changed(); }
            @Override public void onDone(String id) { ended(); }
            @Override public void onError(String id) { ended(); }
        });
        ready = true;
        for (String text : waiting) speak(text, waitingRate);
        waiting.clear();
    }

    private static void ended() {
        if (active.decrementAndGet() > 0) return;
        active.set(0);
        main.postDelayed(new Runnable() {
            @Override public void run() { if (active.get() <= 0) { Hub.speaking = false; Hub.changed(); } }
        }, 250);
    }

    private static void speak(String text, float rate) {
        tts.setSpeechRate(rate);
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "earpiece-" + (++counter));
    }

    /**
     * Says the text. Returns false, and stays silent, when "never use the phone speaker" is on
     * and no earbud or headphones are connected.
     */
    static synchronized boolean say(Context c, String text, Prefs p) {
        if (p.earbudOnly && !earbudConnected(c)) return false;
        init(c);
        if (tts == null) return false;
        if (!ready) { waiting.add(text); waitingRate = p.rate; return true; }
        speak(text, p.rate);
        return true;
    }

    /** Stops talking at once and forgets anything queued. */
    static synchronized void hush() {
        waiting.clear();
        if (tts != null && ready) tts.stop();
        active.set(0);
        Hub.speaking = false;
    }

    static boolean earbudConnected(Context c) {
        AudioManager am = (AudioManager) c.getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return false;
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            int t = d.getType();
            if (t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                    || t == AudioDeviceInfo.TYPE_WIRED_HEADSET
                    || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                    || t == AudioDeviceInfo.TYPE_USB_HEADSET
                    || t == 23      // hearing aid
                    || t == 26)     // Bluetooth LE Audio headset
                return true;
        }
        return false;
    }
}
