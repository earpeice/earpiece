package com.earpiece.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Locale;

/** Settings. Everything is saved when the screen is left. */
public final class SettingsActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private LinearLayout root;
    private Prefs p;
    private int micAtOpen;
    private EditText apiKey, baseUrl, sttModel, chatModel, notes, language;
    private SeekBar maxWords, rate, sensitivity, pause;
    private TextView maxWordsOut, rateOut, sensitivityOut, pauseOut, checkOut, batteryOut;
    private Spinner answerMode, mic;
    private Switch earbudOnly, keepAwake, mute;

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout.LayoutParams below(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.topMargin = dp(topDp);
        return lp;
    }

    private void section(String title) { root.addView(text(title, 18, MainActivity.SCRIPT, true), below(30)); }

    private void help(String s) { root.addView(text(s, 14, MainActivity.DIM, false), below(6)); }

    private EditText field(String label, String value, String hint, int inputType) {
        root.addView(text(label, 15, MainActivity.DIM, false), below(14));
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setHintTextColor(MainActivity.FAINT);
        e.setTextColor(MainActivity.SCRIPT);
        e.setTextSize(16);
        e.setInputType(inputType);
        root.addView(e, new LinearLayout.LayoutParams(MATCH, WRAP));
        return e;
    }

    /** A labelled slider; returns the label that shows its current value through out[0]. */
    private SeekBar slider(String label, int steps, int at, TextView[] out) {
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.addView(text(label, 15, MainActivity.DIM, false), new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView value = text("", 15, MainActivity.SCRIPT, false);
        head.addView(value, new LinearLayout.LayoutParams(WRAP, WRAP));
        root.addView(head, below(14));
        SeekBar s = new SeekBar(this);
        s.setMax(steps);
        s.setProgress(Math.max(0, Math.min(steps, at)));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) { labels(); }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });
        root.addView(s, below(4));
        out[0] = value;
        return s;
    }

    private Spinner choice(String label, String[] items, int at) {
        root.addView(text(label, 15, MainActivity.DIM, false), below(14));
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        s.setSelection(Math.max(0, Math.min(items.length - 1, at)));
        root.addView(s, below(4));
        return s;
    }

    private Switch toggle(String label, boolean on) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextSize(15);
        s.setTextColor(MainActivity.SCRIPT);
        s.setChecked(on);
        root.addView(s, below(16));
        return s;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(16);
        return b;
    }

    // slider positions <-> values
    private int wordsValue() { return maxWords.getProgress() + 1; }                 // 1..15
    private float rateValue() { return 0.8f + rate.getProgress() * 0.05f; }         // 0.80..2.00
    private int sensitivityValue() { return sensitivity.getProgress() + 1; }        // 1..10
    private int pauseValue() { return 400 + pause.getProgress() * 50; }             // 400..1500 ms

    private void labels() {
        if (maxWords == null || rate == null || sensitivity == null || pause == null) return;
        int w = wordsValue();
        maxWordsOut.setText(w + (w == 1 ? " word" : " words"));
        rateOut.setText(String.format(Locale.US, "%.2f×", rateValue()));
        int s = sensitivityValue();
        sensitivityOut.setText(s <= 3 ? "low, for noisy places" : s >= 8 ? "high, for quiet voices" : "medium");
        pauseOut.setText(String.format(Locale.US, "%.2f s", pauseValue() / 1000.0));
    }

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        p = Prefs.load(this);
        micAtOpen = p.mic;

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(14), dp(20), dp(40));
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(MainActivity.WINGS);
        scroll.addView(root, new ViewGroup.LayoutParams(MATCH, WRAP));
        setContentView(scroll);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Settings", 20, MainActivity.SCRIPT, true);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView done = text("Done", 16, MainActivity.BLUE, true);
        done.setPadding(0, dp(10), 0, dp(10));
        done.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        top.addView(done, new LinearLayout.LayoutParams(WRAP, WRAP));
        root.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));

        int plain = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;

        section("Answer service");
        apiKey = field("API key", p.apiKey, "gsk_…", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        help("Kept only on this phone. It is the same key you used on the web page.");
        Button check = button("Check the key");
        root.addView(check, below(8));
        checkOut = text("", 14, MainActivity.DIM, false);
        root.addView(checkOut, below(4));
        check.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { checkKey(); }
        });
        chatModel = field("Answer model", p.chatModel, Prefs.GROQ_CHAT, plain);
        help("Use the one that was fastest for you on the web page.");
        sttModel = field("Speech-to-text model", p.sttModel, Prefs.GROQ_STT, plain);
        baseUrl = field("Address of the service", p.baseUrl, Prefs.GROQ_URL, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        Button reset = button("Go back to the Groq defaults");
        root.addView(reset, below(8));
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                baseUrl.setText(Prefs.GROQ_URL);
                sttModel.setText(Prefs.GROQ_STT);
                chatModel.setText(Prefs.GROQ_CHAT);
            }
        });

        section("Answers");
        TextView[] out = new TextView[1];
        maxWords = slider("Longest answer", 14, p.maxWords - 1, out);
        maxWordsOut = out[0];
        answerMode = choice("What to answer", new String[]{"Only questions it hears", "Anything it can help with"}, p.answerAnything ? 1 : 0);
        notes = field("Things it should know", p.notes, "Your name and job, what today's meeting is about, facts you might be asked for…",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        notes.setMinLines(3);
        notes.setGravity(Gravity.TOP);
        language = field("Language spoken around you", p.language, "en, es, fr… leave empty to detect", plain);

        section("Voice in your ear");
        earbudOnly = toggle("Never use the phone speaker", p.earbudOnly);
        help("With this on, answers are only spoken when an earbud or headphones are connected. If the earbud drops out, the app stays silent.");
        keepAwake = toggle("Keep the earbud awake", p.keepAwake);
        help("Stops the first word of an answer being cut off. Uses a little more earbud battery. Takes effect the next time you start listening.");
        rate = slider("Speed", 24, Math.round((p.rate - 0.8f) / 0.05f), out);
        rateOut = out[0];
        help("The voice itself is chosen in the phone's Settings, under Accessibility, Text-to-speech output.");

        section("Microphone");
        mic = choice("Microphone", new String[]{"Let the phone choose", "The phone's own microphone", "A plugged-in microphone (USB or headset jack)"}, p.mic);
        help("A plugged-in microphone is normally picked up automatically. If you plug one in, connect the earbud after it.");
        sensitivity = slider("Sensitivity", 9, p.sensitivity - 1, out);
        sensitivityOut = out[0];
        pause = slider("Wait after speech stops", 22, Math.round((p.pauseMs - 400) / 50f), out);
        pauseOut = out[0];
        mute = toggle("Ignore the microphone while an answer is being spoken", p.muteWhileSpeaking);

        section("Running with the screen off");
        help("Some phones stop background apps to save battery. Allowing this app to run unrestricted keeps it listening after you lock the phone.");
        Button battery = button("Allow it to keep running");
        root.addView(battery, below(8));
        batteryOut = text("", 14, MainActivity.DIM, false);
        root.addView(batteryOut, below(4));
        battery.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { askBattery(); }
        });

        labels();
    }

    @Override protected void onResume() {
        super.onResume();
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean allowed = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        batteryOut.setText(allowed ? "Already allowed." : "Not allowed yet.");
    }

    private void collect() {
        p.apiKey = apiKey.getText().toString().trim();
        String url = baseUrl.getText().toString().trim();
        p.baseUrl = url.isEmpty() ? Prefs.GROQ_URL : url;
        String stt = sttModel.getText().toString().trim();
        p.sttModel = stt.isEmpty() ? Prefs.GROQ_STT : stt;
        String chat = chatModel.getText().toString().trim();
        p.chatModel = chat.isEmpty() ? Prefs.GROQ_CHAT : chat;
        p.notes = notes.getText().toString();
        p.language = language.getText().toString().trim();
        p.maxWords = wordsValue();
        p.answerAnything = answerMode.getSelectedItemPosition() == 1;
        p.earbudOnly = earbudOnly.isChecked();
        p.keepAwake = keepAwake.isChecked();
        p.rate = rateValue();
        p.mic = Math.max(0, mic.getSelectedItemPosition());
        p.sensitivity = sensitivityValue();
        p.pauseMs = pauseValue();
        p.muteWhileSpeaking = mute.isChecked();
    }

    @Override protected void onPause() {
        collect();
        p.save(this);
        if (Hub.running && p.mic != micAtOpen) {
            micAtOpen = p.mic;
            try {
                startService(new Intent(this, ListenService.class).setAction(ListenService.ACTION_RELOAD));
            } catch (RuntimeException ignored) { }
        }
        super.onPause();
    }

    private void checkKey() {
        collect();
        final Prefs snapshot = p;
        snapshot.save(this);
        checkOut.setTextColor(MainActivity.DIM);
        checkOut.setText("Checking…");
        new Thread(new Runnable() {
            @Override public void run() {
                String message;
                boolean good;
                try {
                    message = Api.check(snapshot);
                    good = "The key works.".equals(message);
                } catch (Api.Failure f) {
                    message = Api.explain(f, "this check");
                    good = false;
                }
                final String m = message;
                final boolean g = good;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        checkOut.setTextColor(g ? MainActivity.GO : MainActivity.STOP);
                        checkOut.setText(m);
                    }
                });
            }
        }, "earpiece-check").start();
    }

    private void askBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        } catch (RuntimeException e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (RuntimeException ignored) {
                batteryOut.setText("Open the phone's Settings, Apps, Earpiece, Battery, and choose Unrestricted.");
            }
        }
    }
}
