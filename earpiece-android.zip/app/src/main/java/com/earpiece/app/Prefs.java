package com.earpiece.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Everything the person can change in Settings. Kept only on this phone. */
final class Prefs {
    static final String GROQ_URL = "https://api.groq.com/openai/v1";
    static final String GROQ_STT = "whisper-large-v3-turbo";
    static final String GROQ_CHAT = "openai/gpt-oss-20b";

    static final int MIC_AUTO = 0, MIC_PHONE = 1, MIC_PLUGGED = 2;

    String apiKey = "";
    String baseUrl = GROQ_URL;
    String sttModel = GROQ_STT;
    String chatModel = GROQ_CHAT;
    String language = "en";
    String notes = "";
    boolean answerAnything = false;
    int maxWords = 6;
    float rate = 1.15f;
    int mic = MIC_AUTO;
    int sensitivity = 6;
    int pauseMs = 700;
    boolean muteWhileSpeaking = false;
    boolean earbudOnly = true;
    boolean keepAwake = true;

    private static SharedPreferences store(Context c) {
        return c.getApplicationContext().getSharedPreferences("earpiece", Context.MODE_PRIVATE);
    }

    static Prefs load(Context c) {
        SharedPreferences s = store(c);
        Prefs p = new Prefs();
        p.apiKey = s.getString("apiKey", p.apiKey);
        p.baseUrl = s.getString("baseUrl", p.baseUrl);
        p.sttModel = s.getString("sttModel", p.sttModel);
        p.chatModel = s.getString("chatModel", p.chatModel);
        p.language = s.getString("language", p.language);
        p.notes = s.getString("notes", p.notes);
        p.answerAnything = s.getBoolean("answerAnything", p.answerAnything);
        p.maxWords = s.getInt("maxWords", p.maxWords);
        p.rate = s.getFloat("rate", p.rate);
        p.mic = s.getInt("mic", p.mic);
        p.sensitivity = s.getInt("sensitivity", p.sensitivity);
        p.pauseMs = s.getInt("pauseMs", p.pauseMs);
        p.muteWhileSpeaking = s.getBoolean("muteWhileSpeaking", p.muteWhileSpeaking);
        p.earbudOnly = s.getBoolean("earbudOnly", p.earbudOnly);
        p.keepAwake = s.getBoolean("keepAwake", p.keepAwake);
        return p;
    }

    void save(Context c) {
        store(c).edit()
                .putString("apiKey", apiKey)
                .putString("baseUrl", baseUrl)
                .putString("sttModel", sttModel)
                .putString("chatModel", chatModel)
                .putString("language", language)
                .putString("notes", notes)
                .putBoolean("answerAnything", answerAnything)
                .putInt("maxWords", maxWords)
                .putFloat("rate", rate)
                .putInt("mic", mic)
                .putInt("sensitivity", sensitivity)
                .putInt("pauseMs", pauseMs)
                .putBoolean("muteWhileSpeaking", muteWhileSpeaking)
                .putBoolean("earbudOnly", earbudOnly)
                .putBoolean("keepAwake", keepAwake)
                .apply();
    }
}
