package com.earpiece.app;

import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** The app's shared state: what the listening service is doing and what has been heard. */
final class Hub {
    private Hub() {}

    interface Listener { void onHubChanged(); }

    static volatile boolean running, hearing, speaking;
    static final AtomicInteger transcribing = new AtomicInteger();
    static final AtomicInteger thinking = new AtomicInteger();
    static volatile String notice = "";
    static volatile double level;

    private static final ArrayList<Entry> entries = new ArrayList<Entry>();
    private static final Handler main = new Handler(Looper.getMainLooper());
    private static volatile Listener listener;

    static void setListener(Listener l) { listener = l; }

    /** Tells the screen, on the main thread, that something changed. */
    static void changed() {
        main.post(new Runnable() {
            @Override public void run() { Listener l = listener; if (l != null) l.onHubChanged(); }
        });
    }

    static void notice(String text) { notice = text == null ? "" : text; changed(); }

    static void add(Entry e) {
        synchronized (entries) { entries.add(e); if (entries.size() > 80) entries.remove(0); }
    }

    static void remove(Entry e) {
        synchronized (entries) { entries.remove(e); }
    }

    static List<Entry> snapshot() {
        synchronized (entries) { return new ArrayList<Entry>(entries); }
    }

    static void clear() {
        synchronized (entries) { entries.clear(); }
        changed();
    }
}
