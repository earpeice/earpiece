package com.earpiece.app;

/** One thing that was heard, and what became of it. */
final class Entry {
    static final int TRANSCRIBING = 0, THINKING = 1, ANSWERED = 2, SKIPPED = 3, ERROR = 4, LATE = 5, UNSPOKEN = 6;

    volatile String heard = "";
    volatile String answer = "";
    volatile String error = "";
    volatile int status = TRANSCRIBING;
    volatile long t0;            // when the speaker stopped (elapsed-realtime clock)
    volatile long sttMs = -1;    // time spent turning speech into text
    volatile long llmMs = -1;    // time spent finding the answer
    volatile long latency = -1;
}
